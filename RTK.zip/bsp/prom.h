#ifndef _PROM_H
#define _PROM_H

extern void prom_printf(char *fmt, ...);
extern void prom_meminit(void);
extern void prom_console_init(void);

#endif /* _PROM_H */
